<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
</head>
<body>


<div class="footer">
  <p>Footer</p>
</div>

</body>
</html>