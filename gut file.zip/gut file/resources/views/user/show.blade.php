<!doctype html>
<html>
    <head>
        

        <title>Uesr Home</title>
        <script type="text/javascript" src="../js/table.js"></script>
        <link rel="stylesheet" type="text/css" href="{{ asset('/css/table.css') }}">
    </head>
    <body>

<form action="/user/show" method="get">
	
	<input type="search" name="search">
	<button type="submit"> search</button>
    


</form>

<table  border="1">
		<tr>
			<th>Id</th>
			<th>Name</th>
			<th>Headline</th>
			<th>File</th>
			<th>Catagory</th>
			<th>Post</th>
			<th>Post Time </th>
			<th>Action </th>
		</tr>
		 @foreach($posts as $post)

		<tr>
			<td>{{ $post->id }}</td>
			<td>{{ $post->name}}</td>
			<td>{{ $post->headline}}</td>
			<td>{{ $post->file }}</td>
			<td>{{ $post->catagory }}</td>
			<td>{{ $post->post }}</td>
			<td>{{ $post->create_time }}</td>
			
			
		<td>
           <a href = 'delete/{{ $post->id }}'>Delete</a>|
           
   		 </td>
		
		@endforeach

	</table>
	
    </body>
</html>