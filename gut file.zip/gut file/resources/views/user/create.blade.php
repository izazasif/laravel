<!DOCTYPE html>
<html >
    <head> 
        <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <link href="{{ asset('/css/post.css') }}" rel="stylesheet">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/css/bootstrapValidator.min.css"/>
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/js/bootstrapValidator.min.js"></script>
 </style>

</head> 
<body>

<div class="container">
    <div class="row">
        <form method="post" enctype="multipart/form-data" >
             {{ csrf_field() }}
                    <div class="row">
                        <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control" name="name" autocomplete="off" id="name" placeholder="input your name">
                        </div>
                    </div>
                        <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" class="form-control" name="headline" autocomplete="off" id="headline" placeholder="input your post headline">
                        </div>
                    </div>

               <div class="col-md-6">
                        <div class="form-group">
                           <input type="file" name="file">
                           <br>
                        </div>
                    </div>
                     <div class="col-md-6">
                        <div class="form-group">
                           <select name="catagory">
                <option value="opinion">Opinion</option>
                <option value="culture">culture</option>
                 <option value="lifestyle">life style</option>
                 <option value="sports">sports</option>
                 </select>
                <br>
                        </div>
                    </div>


                    </div>
                    <div class="row">
                        <div class="col-md-12">
                        <div class="form-group">
                            <textarea class="form-control textarea" rows="3" name="post" id="Message" placeholder="Message"></textarea>
                        </div>
                    </div>
                    </div>
                    <div class="row">
                    <div class="col-md-12">
                  <button type="submit" class="btn main-btn pull-right">Create Post</button>
                  </div>
                  </div>
                </form>
    </div>
</div>
</body>
</html>