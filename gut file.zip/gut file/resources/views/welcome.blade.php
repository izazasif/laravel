@include('header')
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
    	 @foreach($posts as $post)
    	<div class="card col-md-12 p-3">
    		<div class="row ">
    			<div class="col-md-4">
    				<img src="/upload/{{$post->file}}" width="140" height="150">
    			</div>
    			<div class="col-md-7">
    				<div class="card-block">
    					<h6 class="card-title">{{ $post->headline }}</h6>
    					<p class="card-text text-justify">{{ $post->post }}</p>
    					<a href="#" class="btn btn-primary">read more...</a>
    				</div>
    			</div>
    		</div>
    	</div>
    	
    	
    @endforeach	
    	
    </div>
</div>
@include('footer')