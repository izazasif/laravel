<!doctype html>
<html>
    <head>
        

        <title>Admin Home</title>
        <script type="text/javascript" src="../js/table.js"></script>
        <link rel="stylesheet" type="text/css" href="{{ asset('/css/table.css') }}">
    </head>
    <body>
<table  border="1">
    <tr>
      <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th>username</th>
      <th>Contact</th>
      <th>UserType</th>
      <th>AddedTime </th>
      <th>Action </th>
    </tr>
     @foreach($posts as $post)

    <tr>
      <td>{{ $post->id }}</td>
      <td>{{ $post->name}}</td>
      <td>{{ $post->email}}</td>
      <td>{{ $post->username }}</td>
      <td>{{ $post->contact }}</td>
      <td>{{ $post->usertype }}</td>
      <td>{{ $post->added }}</td>
      
      
    <td>
           <a href = 'delete/{{ $post->id }}'>Delete</a>|
           <a href = "{{route('user.update',[$post->id])}}">Edit</a>|
           
       </td>
    
    @endforeach

  </table>
  
    </body>
</html>