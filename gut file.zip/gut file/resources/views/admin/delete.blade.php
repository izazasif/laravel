<!DOCTYPE html>
<html>
<head>
	<title>Details</title>
</head>
<body>
		<h2>Account Details</h2>
		
		<table>
			<tr>
			
		</table>

		<h3>Are you sure? </h3>
		<form method="post">
	           <input type="text" name="id">
	           
			<input type="submit" name="submit" value="Confirm"/>
		</form>
		
</body>
</html>
