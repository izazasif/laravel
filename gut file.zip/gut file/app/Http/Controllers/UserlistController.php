<?php

namespace App\Http\Controllers;

use App\userlist;
use Illuminate\Http\Request;

class UserlistController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\userlist  $userlist
     * @return \Illuminate\Http\Response
     */
    public function show(userlist $userlist)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\userlist  $userlist
     * @return \Illuminate\Http\Response
     */
    public function edit(userlist $userlist)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\userlist  $userlist
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, userlist $userlist)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\userlist  $userlist
     * @return \Illuminate\Http\Response
     */
    public function destroy(userlist $userlist)
    {
        //
    }
}
