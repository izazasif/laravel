<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\userlist;
use App\file;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;

class userController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('user.index');
    }
    public function index1()
    {
        return view('user.create');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = new file;
    date_default_timezone_set('Asia/Dhaka');
        $user->name            = $request->name;
        $user->headline            = $request->headline;
        $file = $request->file('file');
        $photoName = date('H-m-s').".".$file->getClientOriginalExtension();
        $user->file = $photoName;
        $file->move('upload/', $photoName);
       $user->catagory            = $request->catagory;
        $user->post            = $request->post;
         $user->create_time   = date('Y-m-d h:m:s');

       
        echo "tyyg";

   $user->save();
   return redirect()->route('user.create');
    
}
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        $post= userlist::find($id);
        return view('user.update')->with('post',$post);
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $post = userlist::find($request->id);
        $post->name    = $request->name;
        $post->contact    = $request->contact;
        $post->password    = $request->password;
       
        $post->save();
                
      
      return redirect()->route('admin.list');
}
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
