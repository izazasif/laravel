<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\userList;
use Illuminate\Support\Facades\DB;
class LoginController extends Controller
{ 
    public function index(Request $request){
        $username = $request->username;
        $password = $request->input('password');

    $user = DB::table('reg')
                    ->where('username', $username)
                    ->where('password', $password)
                    ->first();
                    
                    

       if($user != null){
            if($user->usertype=='Admin'){
                $request->session()->put('logged', $user);
                return redirect()->route('admin.index',['name'=>$user]);
            }
            else {
                $request->session()->put('logged', $user);
                return redirect()->route('user.index',['name'=>$user]);
            }
          
        }else{
            $request->session()->flash('message', 'Invalid username or password'); 
        return redirect()->route('login');
        }
    }
}
