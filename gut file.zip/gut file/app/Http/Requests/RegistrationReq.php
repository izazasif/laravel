<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegistrationReq extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
             return [
            'email'=>'Required|unique:reg',
            'username'=>'Required|unique:reg'
        
        ];
    }
     public function messages(){
        return [
            'email.required' => "can't left empty",
            'email.unique'  => ' email allready in used',
            'username.required' => "can't left empty",
            'username.unique'  => 'user name all ready in used'
        ];
    }
}
