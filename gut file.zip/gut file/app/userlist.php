<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userlist extends Model
{
     protected $table = 'reg';
     protected $primaryKey = 'id';
      public $timestamps = false;
}
