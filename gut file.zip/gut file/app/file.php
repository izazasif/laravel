<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class file extends Model
{
     protected $table = 'catagory';
     protected $primaryKey = 'id';
      public $timestamps = false;
}
