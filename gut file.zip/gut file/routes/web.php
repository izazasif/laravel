<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
	$posts = DB::table('catagory')->get();
     return view('welcome',['posts'=>$posts]);
    
});
/*Route::get('/ab', function () {
    return view('registration');
});
*/

Route::get('/welcome/registration', 'basicController@index')->name('registration');
Route::post('/welcome/registration', 'basicController@store');
Route::get('/welcome/login', 'basicController@login')->name('login');
Route::post('/welcome/login', 'LoginController@index');

Route::group(['middleware'=>['sess']],function(){
Route::get('/user/index', 'userController@index')->name('user.index');

Route::get('/user/create', 'userController@index1')->name('user.create');
Route::post('/user/create', 'userController@store');

Route::get('/user/update/{id}', 'userController@edit')->name('user.update');
Route::post('/user/update/{id}', 'userController@update');

Route::get('/user/show', 'showController@show')->name('user.show');
Route::get('/user/delete/{id}','showController@destroy');



Route::get('/admin/delete', 'adminController@index')->name('admin.delete');

Route::get('/admin/list', 'adminController@show1')->name('admin.list');
Route::get('/admin/delete/{id}','adminController@destroy');


Route::get('/admin/index', 'adminController@index1')->name('admin.index');

Route::get('/welcome/logout','logoutController@index')->name('logout');

});